// Place fonts/font-FontIcon.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: font-FontIcon
//      fonts:
//       - asset: fonts/font-FontIcon.ttf
import 'package:flutter/widgets.dart';

class Font_FontIcon {
  Font_FontIcon._();

  static const String _fontFamily = 'font-FontIcon';

  static const IconData support = IconData(0xe914, fontFamily: _fontFamily);
  static const IconData warning = IconData(0xe91b, fontFamily: _fontFamily);
}
