/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'font-FontIcon\'">' + entity + '</span>' + html;
	}
	var icons = {
		'font-paper-plane-svgrepo-com': '&#xe915;',
		'font-chat-svgrepo-com': '&#xe91f;',
		'font-shopping-cart-svgrepo-com': '&#xe920;',
		'font-heart1': '&#xe921;',
		'font-money': '&#xe906;',
		'font-aparat': '&#xe900;',
		'font-arrow': '&#xe901;',
		'font-awards': '&#xe902;',
		'font-awsome': '&#xe903;',
		'font-brands': '&#xe904;',
		'font-cart': '&#xe905;',
		'font-category': '&#xe907;',
		'font-check-circle': '&#xe908;',
		'font-clock': '&#xe90a;',
		'font-download': '&#xe90c;',
		'font-edit': '&#xe90d;',
		'font-faq': '&#xe90e;',
		'font-filter': '&#xe90f;',
		'font-heart': '&#xe910;',
		'font-instagram': '&#xe911;',
		'font-latest': '&#xe912;',
		'font-play': '&#xe913;',
		'font-post': '&#xe914;',
		'font-search': '&#xe916;',
		'font-support': '&#xe917;',
		'font-telegram': '&#xe918;',
		'font-timer': '&#xe919;',
		'font-trash': '&#xe91a;',
		'font-twitter': '&#xe91b;',
		'font-user': '&#xe91c;',
		'font-users': '&#xe91d;',
		'font-warning': '&#xe91e;',
		'font-reply-1': '&#xe90b;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/font-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
